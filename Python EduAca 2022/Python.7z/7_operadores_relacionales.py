# Los operadores son simboles que indican como se manipulan los datos

# Operadores relacionales - Devuelven un valor booleano.
"""
==  -   Son iguales
!=  -   Son distintos
>   -   Mayor que
<   -   Menor que
>=  -   Mayor o igual que
<=  -   Menor o igual que
"""


numero1 = 5
numero2 = 5

print(numero1 == numero2)
print(numero1 != numero2)
print(numero1 > numero2)
print(numero1 < numero2)
print(numero1 >= numero2)
print(numero1 <= numero2)
