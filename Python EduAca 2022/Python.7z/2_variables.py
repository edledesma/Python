# TIPOS DE VARIABLES
# ENTEROS (INT)- Todos los números positivos y negativos, incluyendo el zero.
numero = 10
print(numero)
print(type(numero))

# DECIMALES (FLOAT) - Todos los números que contengan decimales o punto separador.
numero = 1.5
print(numero)
print(type(numero))

# CADENAS (STR) - Todos los textos que se encuentren entre comillas.
cadena = "Hola"
print(cadena)
print(type(cadena))

# BOOLEANOS - (BOOL) - Solamente devuelve True (Verdadero) o False (Falso)
booleano = True
print(booleano)
print(type(booleano))
