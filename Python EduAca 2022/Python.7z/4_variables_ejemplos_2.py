# Variables para nombre, apellido, nacionalidad y edad
nombre = "Joaquin"
apellido = "Romero"
nacionalidad = "Argentino"
edad = 41

print(f"Hola {nombre}, tu apellido es {apellido}. Sos {nacionalidad} con {edad} años de edad ")
