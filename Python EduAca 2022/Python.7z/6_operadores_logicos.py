# Los operadores son simboles que indican como se manipulan los datos

# Operadores lógicos - Sirven para trabajar con datos booleanos. And (Y), or (O) y not (NO).

aprobado = False
libre = True
print(aprobado and libre)

print(aprobado or libre)

print(not aprobado)

