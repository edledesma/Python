# Los operadores son simboles que indican como se manipulan los datos

# Operadores aritméticos - Suma + , resta - , multiplicación *, division / y el módulo %.

numero1 = int(input("Ingresa un número (1): "))
numero2 = int(input("Ingresa un número (2): "))

# Suma
print(f"La suma es {numero1 + numero2}")
# Resta
print(f"La resta es {numero1 - numero2}")
# Multiplicación
print(f"La multiplicación es {numero1 * numero2}")
# Division
print(f"La division es {numero1 / numero2}")
# Modulo
print(f"El modulo es {numero1 % numero2}")

# Operadores lógicos - Sirven para trabajar con datos booleanos. And (Y), or (O) y not (NO).

aprobado = True
libre = False
print(a and b)


# Operadores relacionales



# Operadores de asignación
