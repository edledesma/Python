"""
Las agendas telefónicas son una guía donde se encuentran los datos de
diferentes personas como su nombre, domicilio y teléfono. Además, sirven para localizar personas, lugares o servicios.

Dicho lo anterior, escribamos un programa que permita guardar nombres y números de teléfono.
El programa nos dará el siguiente menú:

Los datos para este ejercicio son los siguientes:

Jose: 302944; Mario: 829455; Angel: 829405 y Luis: 930594.


"""